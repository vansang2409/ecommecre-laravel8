<div class="wrap-icon-section minicart">
	<a href="<?php echo e(route('product.cart')); ?>" class="link-direction">
		<i class="fa fa-shopping-basket" aria-hidden="true"></i>
		<?php if(Cart::instance('cart')->count() > 0): ?>
		<div class="left-info">
			<span class="index"><?php echo e(Cart::instance('cart')->count()); ?> items</span>
			<span class="title">CART</span>
		</div>
		<?php endif; ?>
	</a>
</div>
<?php /**PATH C:\laragon\www\Ecommerce\resources\views/livewire/cart-count-component.blade.php ENDPATH**/ ?>